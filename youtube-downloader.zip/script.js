async function processVideo() {
    const url = document.getElementById('videoUrl').value;
    if (!url) {
        alert('Please enter a valid URL');
        return;
    }

    const response = await fetch(`/fetch-info?url=${encodeURIComponent(url)}`);
    const data = await response.json();

    if (data.error) {
        alert(data.error);
        return;
    }

    // थंबनेल और टाइटल दिखाएं
    document.getElementById('thumbnail').src = data.thumbnail;
    document.getElementById('title').innerText = data.title;
    document.getElementById('videoInfo').style.display = 'block';

    // क्वालिटी बटन जेनरेट करें
    const qualitiesDiv = document.getElementById('qualities');
    qualitiesDiv.innerHTML = '';
    data.formats.forEach(format => {
        const btn = document.createElement('button');
        btn.className = 'quality-btn';
        btn.innerText = `${format.quality} (${format.size})`;
        btn.onclick = () => window.open(format.url);
        qualitiesDiv.appendChild(btn);
    });
}